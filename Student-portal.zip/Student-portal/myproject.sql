-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2023 at 10:54 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_form`
--

DROP TABLE IF EXISTS `tbl_form`;
CREATE TABLE IF NOT EXISTS `tbl_form` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mobile` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `college` varchar(255) NOT NULL,
  `gname` varchar(255) NOT NULL,
  `gmobile` varchar(13) NOT NULL,
  `course` varchar(60) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `year` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `technology` varchar(100) NOT NULL,
  `rdate` varchar(60) NOT NULL,
  `accommodation` varchar(30) NOT NULL,
  `mess` varchar(30) NOT NULL,
  `photo_name` varchar(60) NOT NULL,
  `photo_type` varchar(60) NOT NULL,
  `photo_tmp` varchar(60) NOT NULL,
  `aadhar_name` varchar(60) NOT NULL,
  `aadhar_type` varchar(60) NOT NULL,
  `aadhar_tmp` varchar(60) NOT NULL,
  `marksheet_name` varchar(60) NOT NULL,
  `marksheet_type` varchar(60) NOT NULL,
  `marksheet_tmp` varchar(60) NOT NULL,
  `district` varchar(100) NOT NULL,
  `pincode` int NOT NULL,
  `address` varchar(100) NOT NULL,
  `checkbox` varchar(60) NOT NULL,
  `status` varchar(5) NOT NULL,
  `date` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_form`
--

INSERT INTO `tbl_form` (`id`, `mobile`, `email`, `name`, `college`, `gname`, `gmobile`, `course`, `branch`, `year`, `gender`, `technology`, `rdate`, `accommodation`, `mess`, `photo_name`, `photo_type`, `photo_tmp`, `aadhar_name`, `aadhar_type`, `aadhar_tmp`, `marksheet_name`, `marksheet_type`, `marksheet_tmp`, `district`, `pincode`, `address`, `checkbox`, `status`, `date`) VALUES
(4, '9984104050', 'dubeyvishal1505@gmail.com', 'vishal', 'K S SAKET PG COLLEGE AYODHYA', 'Shiv shankar pal', '9026763974', 'B.tech', 'Computer Science Engineering', '2nd Year', 'Male', 'PHP with Laravel/CI', '9 july 2023', 'Hostal', 'Yes', 'Testimonial.png', 'image/png', 'C:wamp64	mpphpAD63.tmp', 'IMG_20211212_154414.jpg', 'image/jpeg', 'C:wamp64	mpphpAD64.tmp', 'dp.pdf', 'application/pdf', 'C:wamp64	mpphpAD85.tmp', 'Lucknow', 224123, 'ijihnihu', 'on', 'N', '0000-00-00 00:00:00.000000'),
(2, '9026763974', 'vp3701273@gmail.com', 'Divyanshu pal', 'K S SAKET PG COLLEGE AYODHYA', 'Shiv shankar pal', '9026763974', 'B.tech', 'Computer Science Engineering', '3rd Year', 'Male', 'Python with Django', '12 july 2023', 'Room', 'Yes', 'Testimonial3.png', 'image/png', 'C:wamp64	mpphp87A.tmp', 'tech.png', 'image/png', 'C:wamp64	mpphp87B.tmp', 'js notes techpile (1).pdf', 'application/pdf', 'C:wamp64	mpphp87C.tmp', 'Lucknow', 224181, 'DFGHG', 'on', 'Y', '0000-00-00 00:00:00.000000'),
(3, '9026763974', 'vp3701273@gmail.com', 'Divyanshu pal', 'K S SAKET PG COLLEGE AYODHYA', 'Shiv shankar pal', '9026763974', 'B.tech', 'Computer Science Engineering', '3rd Year', 'Male', 'Python with Django', '12 july 2023', 'Room', 'Yes', 'Testimonial3.png', 'image/png', 'C:wamp64	mpphpCA27.tmp', 'tech.png', 'image/png', 'C:wamp64	mpphpCA28.tmp', 'js notes techpile (1).pdf', 'application/pdf', 'C:wamp64	mpphpCA29.tmp', 'Lucknow', 224181, 'DFGHG', 'on', 'N', '0000-00-00 00:00:00.000000'),
(5, '9984104050', 'dubeyvishal1505@gmail.com', 'vishal', 'K S SAKET PG COLLEGE AYODHYA', 'Shiv shankar pal', '9026763974', 'B.tech', 'Computer Science Engineering', '2nd Year', 'Male', 'PHP with Laravel/CI', '9 july 2023', 'Hostal', 'Yes', 'Testimonial.png', 'image/png', 'C:wamp64	mpphp25ED.tmp', 'IMG_20211212_154414.jpg', 'image/jpeg', 'C:wamp64	mpphp25EE.tmp', 'dp.pdf', 'application/pdf', 'C:wamp64	mpphp25FF.tmp', 'Lucknow', 224123, 'ijihnihu', 'on', 'Y', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registered`
--

DROP TABLE IF EXISTS `tbl_registered`;
CREATE TABLE IF NOT EXISTS `tbl_registered` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(60) NOT NULL,
  `mobile` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_registered`
--

INSERT INTO `tbl_registered` (`id`, `name`, `college`, `email`, `mobile`) VALUES
(1, 'Divyanshu pal', 'K S SAKET PG COLLEGE AYODHYA', 'vp3701273@gmail.com', 9026763974),
(2, 'Shoiab', 'K S SAKET PG COLLEGE AYODHYA', 'awnishmmg.41@gmail.com', 78675467809),
(3, 'Shoiab', 'K S SAKET PG COLLEGE AYODHYA', 'awnishmmg.41@gmail.com', 78675467809),
(4, 'Vishal', 'K S SAKET PG COLLEGE AYODHYA', 'dubeyvishal1505@gmail.com', 9984104050),
(6, 'Divyanshu pal', 'K S SAKET PG COLLEGE AYODHYA', 'vp3701273@gmail.com', 9026763974);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
