<div class="navbar">
        <ul>
            <li><a href="admin.php" class="active">Welcome -Admin</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="viewallreg.php">View all registration</a></li>
            <li><a href="notapproved.php">Not Approved Student</a></li>
            <li><a href="approve.php">View Approved Student</a></li>
            <li><a href="verify.php">Verify Students</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>