<?php
session_start();
if($_SESSION["user"]=="" && ($_SESSION["user"]==0))
{

    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        .header {
            
            position: fixed;
            z-index: 99;
            text-align: center;
            width: 100%;

        }
        .abcd{
            height: 80px;
        }

        .header .container-fluid {
            background-color: #f1f1f1;
        }

        .img {
            height: 100px;
            width: 150px;
        }

        .head {
            padding-top: 220px;
        }

        ul {
            padding: 15px;
            overflow: auto;
            background-color: blue;
            margin-top: 110px;
            height: 400px;
            /* position: fixed; */
        }

        li {
            text-align: center;
            display: block;

            border: 2px solid red;
        }

        li a {
            text-decoration: none;
            padding: 8px 16px;
            color: white;
        }

        li a:active {
            background-color: aqua;
        }

        li a:hover {
            background-color: gray;
            color: white;
        }

    </style>
</head>

<body>


    <div class="header">
        <div class="container-fluid">
            <div class="row abcd">
                <div class="col-sm-2">
                    <img src="img/spi_logo.png" alt="" height="80px">
                </div>
                <div class="col-sm-6">
                    <h4>Softpro Learning Center</h4>
                    <h5 style="color: orange;">A Unit of Softpro Group of Companies</h5>
                </div>
                <div class="col-sm-4">
                    <button onclick="location.href='http://localhost/my-project/admin/index.php'"> Admin Login</button>
                </div>
            </div>
        </div>

    </div>
    <div class="container-fluid" >
        <div class="row">
            <div class="col-sm-4">
                <?php
                include("navbar.php")
                ?>
            </div>
            <div class="col-sm-8" style="margin-top: 84px;">
                <table>
                    <form action="connect.php" method="post" class="form-control">
                        <tr>
                            <td>Name</td>
                            <td><input type="text" name="name" id="name" placeholder="Enter The Name" class="form-control"></td>
                        </tr>
                        <tr>
                            <td>College</td>
                            <td><input type="text" name="college" id="college" placeholder="Enter The college name" class="form-control"></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><input type="email" name="email" id="email" placeholder="Enter The email Address" class="form-control"></td>
                        </tr>
                        <tr>
                            <td>Mobile</td>
                            <td><input type="number" name="mobile" id="mobile" placeholder="Enter The Mobile No" maxlength="11" minlength="10" class="form-control"></td>
                        </tr>
                        <tr>
                            <td>Submit</td>
                            <td><input type="submit" value="submit"></td>
                        </tr>
                    </form>
                </table>
                <table style="margin-top: 20px; border:3px solid black;" class="table table-stripped">

                    <tr>

                        <td>Name</td>
                        <td>College</td>
                        <td>Email</td>
                        <td>Mobile</td>
                    </tr>
                    <tr>

                        <?php
                        $con = mysqli_connect("localhost", "root", "", "myproject");
                        $query = "select * from tbl_registered";
                        $result = mysqli_query($con, $query);
                        while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['college']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['mobile']; ?></td>
                    </tr>

                <?php
                        };
                ?>

                </table>
            </div>
        </div>
    </div>

</body>

</html>