<?php
session_start();
if($_SESSION["user"]=="" && ($_SESSION["user"]==0))
{
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="header.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        ul {
            padding: 15px;
            overflow: auto;
            background-color: blue;
            margin-top: 110px;
            height: 400px;
            /* position: fixed; */
        }

        li {
            text-align: center;
            display: block;

            border: 2px solid red;
        }

        li a {
            text-decoration: none;
            padding: 8px 16px;
            color: white;
        }

        li a:active {
            background-color: aqua;
        }

        li a:hover {
            background-color: gray;
            color: white;
        }
    </style>
    
  
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Student', 'status'],
          ['Approved',     <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form where status='Y'";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>],
          ['Not Approved',      <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form where status='N'";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>],
        ]);

        var options = {
          title: 'Reported Student Details',
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Registered','Approved','Not Approved'],
          ['2022', 10, 4, 2],
          ['2023', <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_registered";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>,<?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form where status='Y'";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?> ,
                        <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form where status='N'";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?> ],
          ['2024', 0, 0, 0]
        ]);

        var options = {
          chart: {
            title: 'Reporting',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  
</head>
<body>
    <?php
    include("header.php")
    ?>
    <div class="row">
        <div class="col-sm-3">
            <?php
            include("navbar.php")
            ?>
        </div>
        <div class="col-sm-9">
            <div class="row">
                <div class="col-sm-3">
                    <div class="well" style="background-color: aqua; height: 100px; text-align:center">
                        <h3>Registered</h3>
                        <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_registered";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well" style="background-color: red; height: 100px; text-align:center">
                        <h3>Approved</h3>
                        <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form where status='Y'";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well" style="background-color: orange; height: 100px; text-align:center">
                        <h3>
                          Not Approved
                        </h3>
                        <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form where status='N'";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="well" style="background-color: pink; height: 100px; text-align:center">
                        <h3>Reported</h3>
                        <?php
                        $con=mysqli_connect("localhost","root","","myproject");
                        $query="select * from tbl_form";
                        $result=mysqli_query($con,$query);
                        $res=mysqli_num_rows($result);
                        echo $res;
                        ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="well" style="background-color: bisque;">
                    <div id="piechart" style="width: 250px; height: 200px;"></div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="well" style="background-color: bisque;">
                    <div id="columnchart_material" style="width: 250px; height: 200px;"></div>
                    </div>
                </div>
            </div>
            <div class="row">
            <table style="margin-top: 20px; border: 3px solid black;" class="table table-stripped">

<tr>

    <th>Name</th>
    <th>College</th>
    <th>Email</th>
    <th>Mobile</th>
</tr>
<tr>

    <?php
    $con = mysqli_connect("localhost", "root", "", "myproject");
    $query = "select * from tbl_registered";
    $result = mysqli_query($con, $query);
    while ($row = mysqli_fetch_assoc($result)) {
    ?>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['college']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['mobile']; ?></td>
</tr>

<?php
    };
?>

</table>
            </div>
        </div>
    </div>
</body>
</html>