<div class="header">
        <div class="container-fluid">
            <div class="row abcd">
                <div class="col-sm-2">
                    <img src="img/spi_logo.png" alt="" height="80px">
                </div>
                <div class="col-sm-6">
                    <h4>Softpro Learning Center</h4>
                    <h5 style="color: orange;">A Unit of Softpro Group of Companies</h5>
                </div>
                <div class="col-sm-4">
                    <button onclick="location.href='http://localhost/my-project/admin/index.php'"> Admin Login</button>
                </div>
            </div>
        </div>

    </div>
